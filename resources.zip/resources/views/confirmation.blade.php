@extends('layouts.app')

@section('content')

<!--Main layout-->
<main class="mt-5 pt-4">
    <div class="container wow fadeIn">

      <!-- Heading -->
      <h2 class="my-5 h2 text-center">Thank you for shopping with us!...</h2>


    </div>
  </main>
  <!--Main layout-->
    
@endsection

@section('extra-js')

@endsection

